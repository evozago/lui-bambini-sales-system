# Sistema de Controle de Vendas – Lui Bambini

Este repositório contém um projeto front‑end simples para o controle de vendas da empresa **Lui Bambini**.  A aplicação tem como base o mockup fornecido (vide PDF) e utiliza o **Supabase** como banco de dados/back‑end.  Todos os códigos são disponibilizados em formato completo, prontos para serem executados localmente.  Este guia foi escrito para pessoas leigas e detalha, passo a passo, como configurar o ambiente, o Supabase, o repositório no GitHub e como executar a aplicação.

> **Importante**: o código foi escrito utilizando **React**, que é uma biblioteca JavaScript muito popular para a criação de interfaces.  Mesmo que você não tenha conhecimento prévio, siga as etapas abaixo cuidadosamente que tudo deverá funcionar corretamente.

## 1. Pré‑requisitos

Antes de começar, será necessário instalar alguns programas em seu computador:

1. **Node.js** – É o interpretador JavaScript utilizado para executar e construir a aplicação.  Baixe a versão LTS (Long Term Support) em <https://nodejs.org> e siga o instalador padrão (Windows, macOS ou Linux).  Ao final, o comando `node -v` no terminal deve mostrar a versão instalada.
2. **Git** – Ferramenta de controle de versão que permite criar e enviar o código para o GitHub.  Baixe em <https://git-scm.com/downloads> e instale com as opções padrão.
3. Uma conta no **GitHub** – Caso ainda não possua, crie em <https://github.com/join>.  Será necessário para armazenar e versionar o código.
4. Uma conta no **Supabase** – Acesse <https://supabase.com> e crie uma conta gratuita.  O Supabase fornece um banco de dados PostgreSQL com APIs prontas para acesso via JavaScript.

## 2. Clonando ou criando o repositório

Você pode começar de duas maneiras:

1. **Clonar este código diretamente:**
   ```bash
   git clone https://github.com/seu‑usuario/lui-bambini-sales-system.git
   cd lui-bambini-sales-system
   ```
   (Substitua `seu‑usuario` pelo nome do seu usuário no GitHub.)

2. **Criar um repositório vazio no GitHub e adicionar o código:**
   - No GitHub, clique em **New repository**, dê o nome `lui-bambini-sales-system` e clique em **Create repository**.
   - Na sua máquina, abra o terminal e execute:
     ```bash
     git init lui-bambini-sales-system
     cd lui-bambini-sales-system
     ```
   - Copie todos os arquivos deste projeto (contidos na pasta `lui-bambini-sales-system`) para a pasta que acabou de iniciar.
   - Faça o commit inicial e envie para o GitHub:
     ```bash
     git add .
     git commit -m "Commit inicial do sistema de vendas"
     git branch -M main
     git remote add origin https://github.com/seu‑usuario/lui-bambini-sales-system.git
     git push -u origin main
     ```

## 3. Configurando o Supabase

Siga os passos abaixo para preparar o banco de dados no Supabase:

1. **Criar um projeto:** Após entrar no painel do Supabase, clique em **New project**. Dê um nome (por exemplo, `lui-bambini`) e escolha uma senha forte para o banco.  Anote a senha, pois você poderá precisar mais tarde.
2. **Obter a URL e a chave anônima (anon key):**
   - No painel do projeto, clique em **Settings → API**.
   - Copie a **URL** (por exemplo, `https://abcxyz.supabase.co`) e a **Anon public API key**.  Esses valores serão utilizados na configuração do front‑end.
3. **Criar tabelas:** No painel Supabase, clique em **SQL editor** e execute o script abaixo para criar as tabelas necessárias.  Copie o conteúdo a seguir e cole no editor do Supabase, depois clique em **Run**:

   ```sql
   -- Criação da tabela de vendedoras
   create table if not exists public.vendedoras (
     id uuid primary key default uuid_generate_v4(),
     nome text not null,
     ativo boolean not null default true
   );

   -- Criação da tabela de vendas
   create table if not exists public.vendas (
     id uuid primary key default uuid_generate_v4(),
     data date not null,
     valor numeric not null,
     vendedora_id uuid references public.vendedoras(id)
   );

   -- Criação da tabela de metas
   create table if not exists public.metas (
     id uuid primary key default uuid_generate_v4(),
     ano integer not null,
     mes integer not null,
     valor numeric not null
   );
   ```

4. **Inserir alguns dados de exemplo (opcional):** Ainda no SQL editor, você pode inserir algumas vendedoras, metas e vendas de teste.  Por exemplo:

   ```sql
   insert into public.vendedoras (nome, ativo) values ('Ana', true), ('Beatriz', true), ('Camila', true), ('Diana', true);

   -- Metas de 2025 (apenas para exemplo, ajuste conforme necessário)
   insert into public.metas (ano, mes, valor) values
     (2025, 1, 481000), (2025, 2, 512669), (2025, 3, 499388),
     (2025, 4, 500300), (2025, 5, 781619), (2025, 6, 721176),
     (2025, 7, 774100), (2025, 8, 557090), (2025, 9, 600000),
     (2025, 10, 700000), (2025, 11, 600000), (2025, 12, 1200000);

   -- Exemplo de vendas (meses 1 a 4)
   insert into public.vendas (data, valor, vendedora_id) values
     ('2025-01-15', 180000, (select id from public.vendedoras where nome='Ana')),
     ('2025-01-20', 150000, (select id from public.vendedoras where nome='Beatriz')),
     ('2025-02-10', 200000, (select id from public.vendedoras where nome='Camila')),
     ('2025-02-28', 120000, (select id from public.vendedoras where nome='Diana')),
     ('2025-03-05', 300000, (select id from public.vendedoras where nome='Ana')),
     ('2025-03-25', 180000, (select id from public.vendedoras where nome='Beatriz')),
     ('2025-04-12', 250000, (select id from public.vendedoras where nome='Camila')),
     ('2025-04-30', 150000, (select id from public.vendedoras where nome='Diana'));
   ```

Esses dados são apenas para testes.  Você poderá importá‑los via planilha ou API posteriormente.

## 4. Configurando a aplicação localmente

1. No terminal, dentro da pasta do projeto (`lui-bambini-sales-system`), instale as dependências JavaScript:
   ```bash
   npm install
   ```
   Esse comando lê o arquivo `package.json` e instala todas as bibliotecas listadas.
2. Crie um arquivo `.env` na raiz do projeto contendo as chaves que você copiou no painel do Supabase (URL e Anon Key):
   ```env
   REACT_APP_SUPABASE_URL=https://seu‑projeto.supabase.co
   REACT_APP_SUPABASE_ANON_KEY=chave‑anonima‐copiada‐do‑painel
   ```
   Substitua pelos valores reais do seu projeto.
3. Execute a aplicação de desenvolvimento:
   ```bash
   npm start
   ```
   O comando abrirá automaticamente uma janela no navegador (endereço padrão `http://localhost:3000`).  Você deverá ver a tela inicial do dashboard com os dados recuperados do Supabase.

## 5. Visão geral da aplicação

O front‑end foi separado em alguns componentes React principais:

### `src/supabaseClient.js`

Arquivo responsável por inicializar o cliente Supabase utilizando as variáveis de ambiente.  Ele exporta o objeto `supabase`, que é utilizado nas outras partes do código.

### `src/App.js`

Componente raiz que define as rotas do aplicativo utilizando `react-router-dom`.  Nesta versão existem três rotas principais:

* `/` – Mostra o **Dashboard**.
* `/vendedoras` – Mostra a lista de **Vendedoras** e suas vendas.
* `/simulacao` – Página de **Simulação** onde é possível estimar valores futuros com base nas metas.

### `src/components/Dashboard.js`

Responsável por carregar e exibir os indicadores principais (vendas totais do ano, crescimento em relação ao ano anterior, número de vendedoras ativas e quantidade de metas batidas).  Também renderiza uma tabela com as vendas x metas mensais e um gráfico de linha mostrando a evolução das vendas nos últimos anos.

As consultas são feitas diretamente no Supabase através do cliente criado em `supabaseClient.js`.  Caso você deseje otimizar, é possível criar **Stored Procedures** no banco de dados e chamá‑las com `supabase.rpc(...)`.

### `src/components/Vendedoras.js`

Faz a listagem de todas as vendedoras cadastradas e exibe, para cada uma, o total vendido no ano atual.  Você também pode estender essa página para mostrar o histórico de vendas por vendedora, adicionar ou remover vendedoras, etc.

### `src/components/Simulacao.js`

Página simples contendo um formulário para simular cenários de vendas futuros.  O cálculo exibido atualmente é apenas ilustrativo; você pode adaptá‑lo para usar seus próprios critérios ou consultar dados reais.

## 6. Enviando alterações para o GitHub

Depois de fazer quaisquer modificações no código, você poderá enviá‑las ao GitHub executando:

```bash
git add .
git commit -m "Descrição das mudanças"
git push
```

Assim, seu repositório no GitHub ficará sempre atualizado.  Você também pode convidar colaboradores e criar *pull requests* para revisar alterações.

## 7. Próximos passos

Este projeto serve como ponto de partida.  Algumas ideias para evoluí‑lo:

* Implementar autenticação de usuários utilizando o módulo de Auth do Supabase.
* Criar gráficos mais complexos ou dashboards adicionais (por exemplo, comparativo por vendedora).
* Conectar a aplicação a uma plataforma de hospedagem (por exemplo, Vercel, Netlify ou GitHub Pages) para disponibilizar o sistema na web.
* Integrar uploads de planilhas ou APIs para importar vendas em massa.

Sinta‑se à vontade para adaptar e melhorar o código conforme as necessidades do seu negócio.