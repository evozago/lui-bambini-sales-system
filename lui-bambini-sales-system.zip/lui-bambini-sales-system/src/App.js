import React from 'react';
import { BrowserRouter, Routes, Route, NavLink } from 'react-router-dom';
import Dashboard from './components/Dashboard';
import Vendedoras from './components/Vendedoras';
import Simulacao from './components/Simulacao';

/**
 * Componente principal que define a estrutura de navegação da aplicação.
 * A barra lateral contém os links para as diferentes páginas (dashboard,
 * vendedoras e simulação).  O conteúdo é trocado de acordo com a rota atual.
 */
function App() {
  // Obtem a data/hora atual para exibir como última atualização
  const now = new Date();
  const lastUpdated = now.toLocaleDateString('pt-BR') + ' ' + now.toLocaleTimeString('pt-BR');

  return (
    <BrowserRouter>
      <div className="app">
        {/* Barra lateral de navegação */}
        <div className="sidebar">
          <div className="logo">
            <div>Lui Bambini</div>
            <small>Controle de Vendas</small>
          </div>
          <nav>
            <NavLink to="/" end className={({ isActive }) => (isActive ? 'active' : '')}>
              Dashboard
            </NavLink>
            <NavLink to="/vendedoras" className={({ isActive }) => (isActive ? 'active' : '')}>
              Vendedoras
            </NavLink>
            <NavLink to="/simulacao" className={({ isActive }) => (isActive ? 'active' : '')}>
              Simulação
            </NavLink>
          </nav>
          <div className="status">
            <div><strong>Status</strong></div>
            <div>Sistema Online</div>
            <div>Dados sincronizados</div>
            <div style={{ marginTop: '1rem' }}>
              <small>Última atualização: {lastUpdated}</small>
            </div>
          </div>
        </div>

        {/* Conteúdo principal alterado pelas rotas */}
        <div className="content">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/vendedoras" element={<Vendedoras />} />
            <Route path="/simulacao" element={<Simulacao />} />
          </Routes>
        </div>
      </div>
    </BrowserRouter>
  );
}

export default App;