import { createClient } from '@supabase/supabase-js';

// Este arquivo inicializa o cliente Supabase.  As URLs e chaves são
// lidas das variáveis de ambiente definidas no arquivo `.env` na
// raiz do projeto.  Nunca exponha sua chave secreta em aplicações
// cliente – use sempre a chave anônima (anon key) fornecida pelo Supabase.

const supabaseUrl = process.env.REACT_APP_SUPABASE_URL;
const supabaseAnonKey = process.env.REACT_APP_SUPABASE_ANON_KEY;

// Cria o cliente supabase
export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Opcionalmente, você poderia configurar logging, interceptadores ou
// definir headers globais aqui.  Consulte a documentação em
// https://supabase.com/docs/reference/javascript/initializing para mais detalhes.