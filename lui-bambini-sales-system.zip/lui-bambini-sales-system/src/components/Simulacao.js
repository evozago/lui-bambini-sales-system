import React, { useEffect, useState } from 'react';
import { supabase } from '../supabaseClient';

/**
 * Página de simulação.  Permite informar um percentual de crescimento
 * desejado e estima o valor total de vendas para o próximo ano com base
 * no total vendido no ano atual.
 */
export default function Simulacao() {
  const [growthPct, setGrowthPct] = useState('10');
  const [currentTotal, setCurrentTotal] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Ao carregar, recuperar o total vendido no ano atual
    async function fetchTotal() {
      try {
        setLoading(true);
        const now = new Date();
        const yearStart = new Date(now.getFullYear(), 0, 1).toISOString();
        const yearEnd = new Date(now.getFullYear(), 11, 31).toISOString();
        const { data: sales, error } = await supabase
          .from('vendas')
          .select('valor, data')
          .gte('data', yearStart)
          .lte('data', yearEnd);
        if (error) throw error;
        let total = 0;
        sales.forEach((s) => {
          total += parseFloat(s.valor);
        });
        setCurrentTotal(total);
      } catch (err) {
        console.error('Erro ao recuperar vendas para simulação:', err);
      } finally {
        setLoading(false);
      }
    }
    fetchTotal();
  }, []);

  // Calcula o valor previsto considerando o percentual informado
  const predicted = currentTotal * (1 + parseFloat(growthPct) / 100);

  const formatCurrency = (value) => {
    return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  return (
    <div>
      <h1>Simulação de Vendas</h1>
      {loading ? (
        <p>Carregando...</p>
      ) : (
        <>
          <p>
            Total vendido em {new Date().getFullYear()}: <strong>{formatCurrency(currentTotal)}</strong>
          </p>
          <div style={{ margin: '1rem 0' }}>
            <label>
              Percentual de crescimento desejado (%):
              <input
                type="number"
                value={growthPct}
                onChange={(e) => setGrowthPct(e.target.value)}
                style={{ marginLeft: '0.5rem' }}
              />
            </label>
          </div>
          <p>
            Valor estimado para o próximo ano:{' '}
            <strong>{formatCurrency(predicted)}</strong>
          </p>
          <p style={{ fontSize: '0.8rem', color: '#6b7280' }}>
            Esta simulação é apenas ilustrativa.  Ajuste o percentual conforme suas expectativas e
            políticas internas.
          </p>
        </>
      )}
    </div>
  );
}