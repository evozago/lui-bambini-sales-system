import React, { useEffect, useState } from 'react';
import { supabase } from '../supabaseClient';

/**
 * Página que lista todas as vendedoras cadastradas e exibe o total de vendas
 * de cada uma no ano corrente.  Poderia ser expandida para permitir
 * cadastrar novas vendedoras, alterar status ou visualizar detalhes.
 */
export default function Vendedoras() {
  const [vendedoras, setVendedoras] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchVendedoras() {
      try {
        setLoading(true);
        // Buscar vendedoras
        const { data: sellers, error: sellersErr } = await supabase
          .from('vendedoras')
          .select('id, nome, ativo');
        if (sellersErr) throw sellersErr;

        // Buscar vendas do ano atual
        const now = new Date();
        const yearStart = new Date(now.getFullYear(), 0, 1).toISOString();
        const yearEnd = new Date(now.getFullYear(), 11, 31).toISOString();
        const { data: sales, error: salesErr } = await supabase
          .from('vendas')
          .select('valor, data, vendedora_id')
          .gte('data', yearStart)
          .lte('data', yearEnd);
        if (salesErr) throw salesErr;

        // Agregar vendas por vendedora
        const salesBySeller = {};
        sales.forEach((s) => {
          const value = parseFloat(s.valor);
          salesBySeller[s.vendedora_id] = (salesBySeller[s.vendedora_id] || 0) + value;
        });

        // Combinar dados
        const list = sellers.map((v) => ({
          id: v.id,
          nome: v.nome,
          ativo: v.ativo,
          total: salesBySeller[v.id] || 0,
        }));
        setVendedoras(list);
      } catch (err) {
        console.error('Erro ao carregar vendedoras:', err);
      } finally {
        setLoading(false);
      }
    }
    fetchVendedoras();
  }, []);

  const formatCurrency = (value) => {
    return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  return (
    <div>
      <h1>Vendedoras</h1>
      {loading ? (
        <p>Carregando...</p>
      ) : (
        <div className="table-container">
          <table>
            <thead>
              <tr>
                <th>Nome</th>
                <th>Status</th>
                <th>Total vendido (ano)</th>
              </tr>
            </thead>
            <tbody>
              {vendedoras.map((v) => (
                <tr key={v.id}>
                  <td>{v.nome}</td>
                  <td>{v.ativo ? 'Ativa' : 'Inativa'}</td>
                  <td>{formatCurrency(v.total)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}