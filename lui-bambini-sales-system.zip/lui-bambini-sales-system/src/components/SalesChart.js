import React from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Line } from 'react-chartjs-2';

// Registrar módulos do Chart.js para evitar erros de importação
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);

/**
 * Componente responsável por desenhar o gráfico de linhas utilizando
 * react-chartjs-2.  Recebe as labels e datasets via prop `chartData`.
 */
export default function SalesChart({ chartData }) {
  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: false,
        text: 'Evolução das Vendas',
      },
    },
    scales: {
      x: {
        title: {
          display: true,
          text: 'Mês',
        },
      },
      y: {
        title: {
          display: true,
          text: 'Valor (R$)',
        },
        ticks: {
          callback: function (value) {
            return value.toLocaleString('pt-BR', {
              style: 'currency',
              currency: 'BRL',
              minimumFractionDigits: 0,
            });
          },
        },
      },
    },
  };

  return <Line options={options} data={chartData} />;
}