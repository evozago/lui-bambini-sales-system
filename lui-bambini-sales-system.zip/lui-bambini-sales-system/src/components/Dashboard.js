import React, { useState, useEffect } from 'react';
import { supabase } from '../supabaseClient';
import SalesChart from './SalesChart';

/**
 * Componente que monta o Dashboard principal.  Ele consulta o Supabase para
 * obter informações de vendas, metas e vendedoras e calcula indicadores como
 * o total de vendas do ano, crescimento percentual em relação ao ano anterior,
 * número de vendedoras ativas e quantidade de metas cumpridas.  Também
 * exibe uma tabela comparativa entre vendas e metas mensais e um gráfico
 * de evolução das vendas.
 */
export default function Dashboard() {
  const [totalSales, setTotalSales] = useState(0);
  const [growth, setGrowth] = useState(0);
  const [activeSellers, setActiveSellers] = useState(0);
  const [goalsAchieved, setGoalsAchieved] = useState(0);
  const [monthlyComparative, setMonthlyComparative] = useState([]);
  const [chartData, setChartData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      try {
        setLoading(true);
        const now = new Date();
        const currentYear = now.getFullYear();
        const prevYear = currentYear - 1;
        const years = [currentYear - 3, currentYear - 2, currentYear - 1, currentYear];

        // 1. Buscar todas as vendas
        const { data: sales, error: salesErr } = await supabase
          .from('vendas')
          .select('valor, data, vendedora_id');
        if (salesErr) throw salesErr;

        // 2. Buscar vendedoras ativas
        const { data: sellers, error: sellersErr } = await supabase
          .from('vendedoras')
          .select('*')
          .eq('ativo', true);
        if (sellersErr) throw sellersErr;
        setActiveSellers(sellers.length);

        // 3. Buscar metas
        const { data: targets, error: targetsErr } = await supabase
          .from('metas')
          .select('ano, mes, valor');
        if (targetsErr) throw targetsErr;

        // Construir dicionários para somar vendas por ano/mês e por vendedora
        const salesByYearMonth = {};
        const salesBySeller = {};
        let totalCurrentYear = 0;
        let totalPrevYear = 0;

        sales.forEach((s) => {
          const date = new Date(s.data);
          const year = date.getFullYear();
          const month = date.getMonth() + 1;
          const value = parseFloat(s.valor);
          // Agrupar por ano e mês
          if (!salesByYearMonth[year]) salesByYearMonth[year] = {};
          salesByYearMonth[year][month] = (salesByYearMonth[year][month] || 0) + value;
          // Agrupar por vendedora
          if (!salesBySeller[s.vendedora_id]) salesBySeller[s.vendedora_id] = 0;
          salesBySeller[s.vendedora_id] += value;
          // Totais anuais para crescimento
          if (year === currentYear) totalCurrentYear += value;
          if (year === prevYear) totalPrevYear += value;
        });

        setTotalSales(totalCurrentYear);
        if (totalPrevYear > 0) {
          setGrowth(((totalCurrentYear - totalPrevYear) / totalPrevYear) * 100);
        }

        // Construir tabela comparativa de meses
        const monthNames = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
        const comparatives = monthNames.map((name, index) => {
          const month = index + 1;
          const row = { mes: name };
          years.forEach((y) => {
            const salesValue = (salesByYearMonth[y] && salesByYearMonth[y][month]) || 0;
            const targetValue = targets.find((t) => t.ano === y && t.mes === month)?.valor || 0;
            row[y] = { sales: salesValue, target: targetValue };
          });
          return row;
        });
        setMonthlyComparative(comparatives);

        // Calcular quantas metas foram batidas no ano atual
        let achieved = 0;
        comparatives.forEach((row) => {
          const cur = row[currentYear];
          if (cur && cur.sales >= cur.target && cur.target > 0) achieved++;
        });
        setGoalsAchieved(achieved);

        // Preparar dados para o gráfico: array de objetos com labels (meses) e datasets para cada ano
        const chartDatasets = years.map((y) => {
          const data = monthNames.map((_, idx) => {
            const month = idx + 1;
            return (salesByYearMonth[y] && salesByYearMonth[y][month]) || 0;
          });
          const colors = {
            [currentYear]: '#f59e0b',
            [currentYear - 1]: '#10b981',
            [currentYear - 2]: '#3b82f6',
            [currentYear - 3]: '#ef4444',
          };
          return {
            label: y.toString(),
            data: data,
            borderColor: colors[y],
            backgroundColor: colors[y],
            tension: 0.2,
          };
        });
        setChartData({ labels: monthNames, datasets: chartDatasets });
      } catch (err) {
        console.error('Erro ao carregar dados do dashboard:', err);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  // Formata valores em reais
  const formatCurrency = (value) => {
    return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  return (
    <div>
      <h1>Dashboard de Vendas</h1>
      {loading ? (
        <p>Carregando dados...</p>
      ) : (
        <>
          {/* Indicadores resumidos */}
          <div className="metrics">
            <div className="metric-box">
              <h3>Vendas do ano</h3>
              <div className="value">{formatCurrency(totalSales)}</div>
              <div className="sub">Ano de {new Date().getFullYear()}</div>
            </div>
            <div className="metric-box">
              <h3>Crescimento</h3>
              <div className="value">{growth.toFixed(1)}%</div>
              <div className="sub">Em relação ao ano anterior</div>
            </div>
            <div className="metric-box">
              <h3>Vendedoras ativas</h3>
              <div className="value">{activeSellers}</div>
              <div className="sub">Equipe atual</div>
            </div>
            <div className="metric-box">
              <h3>Metas batidas</h3>
              <div className="value">{goalsAchieved}</div>
              <div className="sub">Meses em {new Date().getFullYear()}</div>
            </div>
          </div>

          {/* Tabela comparativa */}
          <div className="table-container">
            <h2>Vendas e Metas Comparativas</h2>
            <table>
              <thead>
                <tr>
                  <th>Mês</th>
                  {monthlyComparative.length > 0 &&
                    Object.keys(monthlyComparative[0])
                      .filter((k) => k !== 'mes')
                      .map((year) => (
                        <th key={year}>{year}</th>
                      ))}
                </tr>
              </thead>
              <tbody>
                {monthlyComparative.map((row) => (
                  <tr key={row.mes}>
                    <td>{row.mes}</td>
                    {Object.keys(row)
                      .filter((k) => k !== 'mes')
                      .map((year) => {
                        const item = row[year];
                        const diff = item.sales - item.target;
                        const pct = item.target > 0 ? (diff / item.target) * 100 : 0;
                        const positive = pct >= 0;
                        return (
                          <td key={year}>
                            <div>{formatCurrency(item.sales)}</div>
                            <div className="sub">Meta {formatCurrency(item.target)}</div>
                            {item.target > 0 && (
                              <div className={positive ? 'sales-positive' : 'sales-negative'}>
                                {positive ? '+' : ''}
                                {pct.toFixed(1)}% vs {parseInt(year) - 1}
                              </div>
                            )}
                          </td>
                        );
                      })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Gráfico de evolução */}
          <div style={{ marginTop: '2rem' }}>
            <h2>Evolução das Vendas</h2>
            {chartData.datasets && <SalesChart chartData={chartData} />}
          </div>
        </>
      )}
    </div>
  );
}